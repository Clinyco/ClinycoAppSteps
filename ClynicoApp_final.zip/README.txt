
Clynico Seguimiento App — versión final con favicon

Instrucciones para publicar:

1. Ve a https://app.netlify.com/drop
2. Arrastra este archivo ZIP completo.
3. Netlify generará tu URL (por ejemplo: https://clynico.netlify.app/)
4. Usa así:
   https://clynico.netlify.app/?zid=123456

El favicon se mostrará automáticamente en pestañas y pantallas de inicio.

© Clínyco — 2025
