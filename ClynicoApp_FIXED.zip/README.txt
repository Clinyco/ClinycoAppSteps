
Clynico Seguimiento App — versión FIX (estilos corregidos)

Publicar en Netlify Drop:
1) https://app.netlify.com/drop
2) Arrastra este ZIP.
3) Abre la URL generada (ej.: https://clynico.netlify.app/)
4) Llama con ?zid=ID_ZENDESK, por ejemplo:
   https://clynico.netlify.app/?zid=123456
